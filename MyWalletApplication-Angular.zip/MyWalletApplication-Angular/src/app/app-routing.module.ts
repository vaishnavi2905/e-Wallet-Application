import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { AddUserComponent } from './add-user/add-user.component';
import { HomeComponent } from './home/home.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent} from './withdraw/withdraw.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { HeaderComponent } from './header/header.component';
const routes: Routes = [
    { path: '', component: HeaderComponent, pathMatch: 'full'},
    { path: 'login', component: LoginComponent},
    { path: 'logout', component: LogoutComponent},
    { path: 'adduser', component: AddUserComponent},
    { path: 'home', component: HomeComponent},
    { path: 'deposit', component: DepositComponent},
    { path: 'withdraw', component: WithdrawComponent},
    { path: 'fundtransfer', component: FundTransferComponent}
  ];
  @NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }