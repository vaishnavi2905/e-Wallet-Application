import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { HttpClientService, User } from '../Service/http-client.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: User = new User("","","","","",null);
  invalidLogin = false
  password;
  constructor(private router: Router,
    private loginservice: AuthenticationService,
    private httpClientService: HttpClientService,
    ) { }

  ngOnInit() {
  }

  goto(){
    this.router.navigate['/adduser'];
  }
  checkLogin() {
    console.log(this.user.contactNumber);
    console.log(this.user.userID);
    this.loginservice.authenticate(this.user).subscribe(
      x=>{
        console.log(x);
        if(x!=null)
        {
          console.log(x);
          sessionStorage.setItem('username', x.accountNumber);
          console.log(x.contactNumber);
          this.invalidLogin = false;
          this.router.navigate(['home']);
        }
        else{
        alert('Invalid credentials!!! Please enter correct details');
        }
      }
    );
  }
}
