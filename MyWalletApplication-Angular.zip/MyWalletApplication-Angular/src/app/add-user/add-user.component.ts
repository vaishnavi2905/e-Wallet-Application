import { Component, OnInit } from '@angular/core';
import { HttpClientService, User } from '../Service/http-client.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  user: User = new User("","","","","",null);
  
  constructor(
    private httpClientService: HttpClientService,
    private router : Router
  ) { }

  ngOnInit() {
  }
  createUser(): void {
    this.httpClientService.createUser(this.user).subscribe( 
      data => 
      {
        if(data=='User already exists'){
          alert("User account already exists.Login to access");
          this.router.navigate(['adduser']);
          return;
        }
        if(data=='Enter correct contact number'){
          alert("Enter correct contact number");
          this.router.navigate(['adduser']);
          return;
        }
        if(data=='true'){
          alert("User registered successfully.");
          this.router.navigate(['login']);
        }
        else{
          alert("Account Number not available in bank. Please enter correct account number");
          this.router.navigate(['adduser']);
        }
      }
    );
  };
}
