import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RequestOptions } from '@angular/http';
import { text } from '@angular/core/src/render3/instructions';

export class User{
  constructor(
    public accountNumber:string,
    public name:string,
    public contactNumber:string,
    public balance:string,
    public userID:string,
    public transaction:Transaction
  ) {}
}
export class Transaction{
  constructor(
    public accountNumber:string,
    public statement:string,
    public time:string,
    public amount:string,
  ) {}
}
@Injectable({
  providedIn: 'root'
})
export class HttpClientService {

  constructor(
    private httpClient:HttpClient
  ) { }

  public createUser(user):Observable<any>{
    return this.httpClient.post<any>("http://localhost:8080/users"+"/create", user,{ responseType: 'text' as 'json' });
  }

  getUser(acc_no):Observable<User>{
    return this.httpClient.get<User>(`http://localhost:8080/users/getUser/${acc_no}`);
  }

  deposit(user,amount):Observable<any>{
    return this.httpClient.post<any>(`http://localhost:8080/users/deposit/${amount}`, user,{ responseType: 'text' as 'json' });
  }

  withdraw(user,amount):Observable<any>{
    return this.httpClient.post<any>(`http://localhost:8080/users/withdraw/${amount}`, user, { responseType: 'text' as 'json' });
  }
  
  fundTransfer(user,amount,accountNumber1):Observable<string>{
    return this.httpClient.post<string>(`http://localhost:8080/users/fundtransfer/${amount}/${accountNumber1}`, user, { responseType: 'text' as 'json' });
  }
}