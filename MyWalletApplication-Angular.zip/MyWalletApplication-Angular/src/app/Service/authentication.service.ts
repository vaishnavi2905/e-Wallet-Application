import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClientService,  User } from '../Service/http-client.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(
    private router: Router,
    private loginservice: AuthenticationService,
    private httpClientService: HttpClientService,
    private httpClient:HttpClient,
    
  ) { }
  
  authenticate(user): Observable<User>{
    return this.httpClient.post<User>("http://localhost:8080/users"+"/doLogin", user);
  }
  
  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    return !(user === null)
  }
  logOut() {
    sessionStorage.removeItem('username')
  }
}