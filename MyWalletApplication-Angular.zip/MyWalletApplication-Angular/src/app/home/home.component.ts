import { Component, OnInit } from '@angular/core';
import { HttpClientService, User, Transaction } from '../Service/http-client.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  user = sessionStorage.getItem('username')
  userData=new User("","","","","",null);
  showtext1=false;
  showtable=false;
  transactions = new Transaction("","","","");
  
  constructor(
    private router: Router,
    private loginservice: AuthenticationService,
    private httpClientService: HttpClientService,
    
  ) { }
  ngOnInit() {
    this.httpClientService.getUser(this.user).subscribe(data => this.userData = data);
    console.log(this.userData);
  }
  showText(){
    this.showtext1=true;
  }
  showTable(){
    this.showtable=true;
  }
  sort(transactions){
    console.log(transactions);
    console.log(transactions.transactions);
    console.log(transactions.transactions.time);
  }
3}
