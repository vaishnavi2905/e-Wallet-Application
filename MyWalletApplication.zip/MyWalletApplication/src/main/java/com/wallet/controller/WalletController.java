package com.wallet.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wallet.model.Bank;
import com.wallet.model.Transaction;
import com.wallet.model.User;
import com.wallet.repository.BankRepository;
import com.wallet.repository.TransactionRepository;
import com.wallet.repository.UserRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping({ "/users"})
public class WalletController {
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private BankRepository bankRepo;
	@Autowired
	private TransactionRepository transactRepo;
	static int i=0;
	
	/****************************LOGIN*****************************/
	@PostMapping("/doLogin")
	public User login(@RequestBody User user) {
		int flag=0;
		Iterable<User> u1 = userRepo.findAll();
		for(User u:u1){
			System.out.println(u);
			if ((u.getContactNumber()==user.getContactNumber()) && (u.getUserID().equals(user.getUserID())))
			{
					System.out.println("login successful");
					flag = 1;
					return u;
			}
		}
		return null;
	}
	
	/****************************USER REGISTER*****************************/
	@PostMapping("/create")
	public boolean create(@RequestBody User user) {
		Iterable<Bank> u1 = bankRepo.findAll();
		for(Bank u:u1){
			if(u.getAccountNumber().equals(user.getAccountNumber())){
				user.setBalance(0);
				user.setName(u.getName());
				userRepo.save(user);
				return true;
			}
		}
		return false;
	}
	
	/****************************GET USER*****************************/
	@GetMapping("/getUser/{acc_no}")
	public User getUser( @PathVariable("acc_no") long acc_no) {
		Optional<User> u = userRepo.findById(acc_no);
		User user = u.get();
		return user;
	}
	
	/****************************DEPOSIT*****************************/
	@PostMapping("/deposit/{amount}")
	public boolean deposit(@RequestBody User user, @PathVariable("amount")  float amount) {
		Optional<User> u = userRepo.findById(user.getAccountNumber());
		Optional<Bank> b = bankRepo.findById(user.getAccountNumber());
		User user1 = u.get();
		Bank bank1 = b.get();
		float bankBalance = bank1.getBalance();
		if(amount<=bankBalance){
			float userBalance = bankBalance + amount;
			user1.setBalance(user1.getBalance()+amount);
			bank1.setBalance(bankBalance-amount);
			bankRepo.save(bank1);
			String statement = "Deposited";
			Date date1 = new Date();
			String date = date1.toString();
			Transaction t = new Transaction(date, user.getAccountNumber(), statement, amount);
			user1.addTransaction(t);
			userRepo.save(user1);
			return true;
		}
		else{
			return false;
		}
}
	
	/****************************FUND TRANSFER*****************************/
	@PostMapping("/fundtransfer/{amount}/{accountNumber1}")
	public boolean fundTransfer( @RequestBody User user, @PathVariable("amount")  float amount,@PathVariable("accountNumber1") long accountNumber1){
		Iterable<User> availableUsers1 = userRepo.findAll();
		Optional<User> user1 = userRepo.findById(user.getAccountNumber());
		User u = user1.get();
		int flag=0;
		User recUser=new User();
		for(User availableUser1:availableUsers1){
			if(availableUser1.getAccountNumber().equals(accountNumber1)){
				System.out.println(u);
				recUser=availableUser1;
				System.out.println(recUser);
				flag=1;
				break;
			}
		}
		if(flag==1){
		System.out.println("hi");
		System.out.println(u.getBalance());
		if(u.getBalance()>=amount){
			//float newBal = 
			u.setBalance(u.getBalance()-amount);
			recUser.setBalance(recUser.getBalance()+amount);
			System.out.println(u.getBalance());
			System.out.println(recUser.getBalance());
			String statement = "Transfered to " + accountNumber1;
			Date date1 = new Date();
			String date = date1.toString();
			Transaction t = new Transaction(date, user.getAccountNumber(), statement, amount);
			System.out.println(t);
			u.addTransaction(t);
			userRepo.save(u);
			System.out.println("user saved");
			
			String statement1 = "Credited from " + user.getAccountNumber();
			Date date2 = new Date();
			String date3 = date2.toString();
			Transaction t1 = new Transaction(date, accountNumber1, statement1, amount);
			recUser.addTransaction(t1);
			userRepo.save(recUser);
			return true;
		}
		}
		if(flag==0){
				Iterable<Bank> availableUsers = bankRepo.findAll();
				for(Bank availableUser:availableUsers){
					if(availableUser.getAccountNumber().equals(accountNumber1)){
						if(u.getBalance()>=amount){
							availableUser.setBalance(availableUser.getBalance()+amount);
							u.setBalance(u.getBalance()-amount);
							String statement = "Transfered to " + accountNumber1;
							Date date1 = new Date();
							String date = date1.toString();
							Transaction t = new Transaction(date, user.getAccountNumber(), statement, amount);
							u.addTransaction(t);
							userRepo.save(u);
							bankRepo.save(availableUser);
							return true;
						}
					}
				}
			}
			return false;
		}
		/*Iterable<Bank> availableUsers = bankRepo.findAll();
		Bank receiver = new Bank();
		User sender = new User();
		float getTransfer=0;
		int flag = 0;
		for(Bank availableUser:availableUsers){
			if(availableUser.getAccountNumber().equals(accountNumber1)){
				receiver = availableUser;
				Optional<User> u = userRepo.findById(user.getAccountNumber());
				sender = u.get();
				float sendTransfer = sender.getBalance()-amount;
				getTransfer = receiver.getBalance()+amount;
				sender.setBalance(sendTransfer);
				receiver.setBalance(getTransfer);
				System.out.println(sender);
				System.out.println(receiver);
				
				bankRepo.save(receiver);
				Optional<Bank> b1 =bankRepo.findById(user.getAccountNumber());
				Bank b_sender = b1.get();
				b_sender.setBalance(sendTransfer);
				bankRepo.save(b_sender);
				flag=1;
			}
		}
		if(flag==0){
			return false;
		}
		Iterable<User> availableUsers1 = userRepo.findAll();
		for(User availableUser1:availableUsers1){
			if(availableUser1.getAccountNumber().equals(receiver.getAccountNumber())){
				flag = 2;
				break;
			}
		}
		User u_receiver = new User();
		if(flag==2){
			System.out.println("welcome");
			Optional<User> u_rec = userRepo.findById(receiver.getAccountNumber());
			u_receiver = u_rec.get();
			u_receiver.setBalance(getTransfer);
			
		}
			
		String statement = "Transfered to " + accountNumber1;
		Date date1 = new Date();
		String date = date1.toString();
		Transaction t = new Transaction(date, user.getAccountNumber(), statement, amount);
		sender.addTransaction(t);
		userRepo.save(sender);
		
		String statement1 = "Credited from " + user.getAccountNumber();
		Date date2 = new Date();
		String date3 = date2.toString();
		Transaction t1 = new Transaction(date, accountNumber1, statement1, amount);
		u_receiver.addTransaction(t1);
		userRepo.save(u_receiver);
		return true;*/
	
	/****************************WITHDRAW*****************************/
	@PostMapping("/withdraw/{amount}")
	public boolean withdraw( @RequestBody User user, @PathVariable("amount")  float amount) {
		Optional<User> u = userRepo.findById(user.getAccountNumber());
		Optional<Bank> b = bankRepo.findById(user.getAccountNumber());
		User user1 = u.get();
		Bank bank1 = b.get();
		float bankBalance = bank1.getBalance();
		float userBalance = user1.getBalance();
		if(userBalance<amount){
			return false;
		}
	
		user1.setBalance(userBalance-amount);
		bank1.setBalance(bankBalance+amount);
		
		bankRepo.save(bank1);
		String statement = "Withdrawn";
		Date date1 = new Date();
		String date = date1.toString();
		Transaction t = new Transaction(date, user.getAccountNumber(), statement, amount);
		user1.addTransaction(t);
		userRepo.save(user1);
		return true;
	}
}