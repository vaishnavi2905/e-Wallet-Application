package com.wallet.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="User_master")
public class User {
	@Id
    private Long accountNumber;
    @Column(name = "userName")
    private String name;
    @Column(name = "contact_no")
    private long contactNumber;
    @Column(name = "balance")
    private float balance;
    @Column(name = "userID")
    private String userID;
    @OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="accountNumber")
	private Set<Transaction> transactions = new HashSet<Transaction>();
    
	public Set<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(Set<Transaction> transactions) {
		this.transactions = transactions;
	}
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	
	public User() {
		
	}
	public void addTransaction(Transaction transaction){
		transactions.add(transaction);
	}
	@Override
	public String toString() {
		return "User [accountNumber=" + accountNumber + ", name=" + name + ", contactNumber=" + contactNumber
				+ ", balance=" + balance + ", userID=" + userID + ", transactions=" + transactions + "]";
	}
	
	
}
