package com.wallet.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bank_master")
public class Bank {
	@Id
    private Long accountNumber;
    @Column(name = "userName")
    private String name;
    @Column(name = "contact_no")
    private long contactNumber;
    @Column(name = "balance")
    private float balance;
    @Column(name="emailID")
    private String emailID;
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public Bank(Long accountNumber, String name, long contactNumber, float balance, String emailID) {
		super();
		this.accountNumber = accountNumber;
		this.name = name;
		this.contactNumber = contactNumber;
		this.balance = balance;
		this.emailID = emailID;
	}
	public Bank() {
		super();
	}
	@Override
	public String toString() {
		return "Bank [accountNumber=" + accountNumber + ", name=" + name + ", contactNumber=" + contactNumber
				+ ", balance=" + balance + ", emailID=" + emailID + "]";
	}
	
}
