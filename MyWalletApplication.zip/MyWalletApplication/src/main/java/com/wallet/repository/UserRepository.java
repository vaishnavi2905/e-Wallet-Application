package com.wallet.repository;

import org.springframework.data.repository.CrudRepository;

import com.wallet.model.User;

public interface UserRepository extends CrudRepository<User, Long>{

}
