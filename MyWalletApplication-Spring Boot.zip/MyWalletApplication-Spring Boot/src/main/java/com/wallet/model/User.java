package com.wallet.model;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.wallet.exception.AmountInsufficientException;

@Entity
@Table(name="User_master")
public class User {
	@Id
    private Long accountNumber;
    @Column(name = "userName")
    private String name;
    @Column(name = "contact_no")
    private BigInteger contactNumber;
    @Column(name = "balance")
    private float balance;
    @Column(name = "userID")
    private String userID;
    @OneToMany(cascade=CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinColumn(name="accountNumber")
	private List<Transaction> transactions = new ArrayList<Transaction>();
    
	public List<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigInteger getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(BigInteger contactNumber) {
		this.contactNumber = contactNumber;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) throws AmountInsufficientException{
		if(balance<0){
			AmountInsufficientException e = new AmountInsufficientException("Amount insufficient");
			throw e;
		}
		this.balance = balance;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	
	public User() {
		
	}
	public void addTransaction(Transaction transaction){
		transactions.add(transaction);
	}
	
	public User(Long accountNumber, String name, BigInteger contactNumber, float balance, String userID) {
		super();
		this.accountNumber = accountNumber;
		this.name = name;
		this.contactNumber = contactNumber;
		this.balance = balance;
		this.userID = userID;
	}
	public User(long accountNumber, BigInteger contactNumber, String userID) {
		this.accountNumber = accountNumber;
		this.contactNumber = contactNumber;
		this.userID = userID;
	}
	@Override
	public String toString() {
		return "User [accountNumber=" + accountNumber + ", name=" + name + ", contactNumber=" + contactNumber
				+ ", balance=" + balance + ", userID=" + userID + ", transactions=" + transactions + "]";
	}
	
	
}
