package com.wallet.model;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
@Entity
@Table(name="Transaction_master")
@IdClass(TransactionID.class)
public class Transaction implements Serializable{
	
	//**********************Class data members****************
	@Id
	@Column(name = "accNumber")
    private Long accountNumber;
	@Id
	private String time;
	@Column(name = "statement")
    private String statement;
    @Column(name = "amount")
    private float amount;
    
  //********************getters and setters*******************
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getStatement() {
		return statement;
	}
	public void setStatement(String statement) {
		this.statement = statement;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	
	//**********************Constructors****************
	public Transaction() {
		super();
	}
	public Transaction(String time, Long accountNumber, String statement, float amount) {
		super();
		this.time = time;
		this.accountNumber = accountNumber;
		this.statement = statement;
		this.amount = amount;
	}
	
	//**********************toString(), hashCode() and equals()****************
	@Override
	public String toString() {
		return "Transaction [accountNumber=" + accountNumber + ", time=" + time + ", statement="
				+ statement + ", amount=" + amount + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountNumber == null) ? 0 : accountNumber.hashCode());
		result = prime * result + Float.floatToIntBits(amount);
		result = prime * result + ((statement == null) ? 0 : statement.hashCode());
		result = prime * result + ((time == null) ? 0 : time.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		if (accountNumber == null) {
			if (other.accountNumber != null)
				return false;
		} else if (!accountNumber.equals(other.accountNumber))
			return false;
		if (Float.floatToIntBits(amount) != Float.floatToIntBits(other.amount))
			return false;
		if (statement == null) {
			if (other.statement != null)
				return false;
		} else if (!statement.equals(other.statement))
			return false;
		if (time == null) {
			if (other.time != null)
				return false;
		} else if (!time.equals(other.time))
			return false;
		return true;
	}
	
}