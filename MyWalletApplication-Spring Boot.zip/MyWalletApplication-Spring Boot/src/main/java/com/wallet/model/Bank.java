package com.wallet.model;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.wallet.exception.AmountInsufficientException;

@Entity
@Table(name="bank_master")
public class Bank {
	@Id
    private Long accountNumber;
    @Column(name = "userName")
    private String name;
    @Column(name = "contact_no")
    private BigInteger contactNumber;
    @Column(name = "balance")
    private float balance;
    @Column(name="emailID")
    private String emailID;
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigInteger getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(BigInteger contactNumber) {
		this.contactNumber = contactNumber;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) throws AmountInsufficientException{
		if(balance<0){
			AmountInsufficientException e = new AmountInsufficientException("Amount insufficient");
			throw e;
		}
		this.balance = balance;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public Bank(Long accountNumber, String name, BigInteger contactNumber, float balance, String emailID) {
		super();
		this.accountNumber = accountNumber;
		this.name = name;
		this.contactNumber = contactNumber;
		this.balance = balance;
		this.emailID = emailID;
	}
	public Bank() {
		super();
	}
	@Override
	public String toString() {
		return "Bank [accountNumber=" + accountNumber + ", name=" + name + ", contactNumber=" + contactNumber
				+ ", balance=" + balance + ", emailID=" + emailID + "]";
	}
	
}
