package com.wallet.model;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.wallet.exception.AmountInsufficientException;

@Entity
@Table(name="bank_master")
public class Bank {
	
	//**********************Class data members****************
	@Id
    private Long accountNumber;
    @Column(name = "userName")
    private String name;
    @Column(name = "contact_no")
    private BigInteger contactNumber;
    @Column(name = "balance")
    private float balance;
    @Column(name="emailID")
    private String emailID;
    
    //********************getters and setters*******************
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigInteger getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(BigInteger contactNumber) {
		this.contactNumber = contactNumber;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) throws AmountInsufficientException{
		if(balance<0){
			AmountInsufficientException e = new AmountInsufficientException("Amount insufficient");
			throw e;
		}
		this.balance = balance;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	
	//**********************Constructors****************
	public Bank() {
		super();
	}
	
	public Bank(Long accountNumber, String name, BigInteger contactNumber, float balance, String emailID) {
		super();
		this.accountNumber = accountNumber;
		this.name = name;
		this.contactNumber = contactNumber;
		this.balance = balance;
		this.emailID = emailID;
	}
	
	//**********************toString(), hashCode() and equals()****************
	@Override
	public String toString() {
		return "Bank [accountNumber=" + accountNumber + ", name=" + name + ", contactNumber=" + contactNumber
				+ ", balance=" + balance + ", emailID=" + emailID + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountNumber == null) ? 0 : accountNumber.hashCode());
		result = prime * result + Float.floatToIntBits(balance);
		result = prime * result + ((contactNumber == null) ? 0 : contactNumber.hashCode());
		result = prime * result + ((emailID == null) ? 0 : emailID.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bank other = (Bank) obj;
		if (accountNumber == null) {
			if (other.accountNumber != null)
				return false;
		} else if (!accountNumber.equals(other.accountNumber))
			return false;
		if (Float.floatToIntBits(balance) != Float.floatToIntBits(other.balance))
			return false;
		if (contactNumber == null) {
			if (other.contactNumber != null)
				return false;
		} else if (!contactNumber.equals(other.contactNumber))
			return false;
		if (emailID == null) {
			if (other.emailID != null)
				return false;
		} else if (!emailID.equals(other.emailID))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
}
