package com.wallet.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wallet.exception.AmountInsufficientException;
import com.wallet.exception.UserNotFoundException;
import com.wallet.model.Bank;
import com.wallet.model.Transaction;
import com.wallet.model.User;
import com.wallet.repository.BankRepository;
import com.wallet.repository.TransactionRepository;
import com.wallet.repository.UserRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping({"/users"})
public class WalletController {
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private BankRepository bankRepo;
	@Autowired
	private TransactionRepository transactRepo;
	static int i=0;
	
	/****************************LOGIN*****************************/
	@PostMapping("/doLogin")
	public User login(@RequestBody User user){
		int flag=0;
		System.out.println(user);
		Iterable<User> u1 = userRepo.findAll();
		for(User u:u1){
			System.out.println(u);
			if ((u.getContactNumber().equals(user.getContactNumber())) && (u.getUserID().equals(user.getUserID())))
			{
					System.out.println("login successful");
					flag = 1;
					return u;
			}
		}
		return null;
	}
	
	/****************************USER REGISTER*******************************/
	@PostMapping("/create")
	public boolean create(@RequestBody User user) throws UserNotFoundException, AmountInsufficientException {
		System.out.println(user);
		try{
			Bank b = bankRepo.findById(user.getAccountNumber()).orElseThrow(() -> new UserNotFoundException("User not found for this id"));
			if(user.getContactNumber().equals(b.getContactNumber()))
			{
				user.setBalance(0);
				user.setName(b.getName());
				userRepo.save(user);
				return true;
			}
			return false;
		}
		catch(UserNotFoundException e){
			System.out.println(e.getMessage());
			String msg = e.getMessage();
			return false;
		}
}
	
	/****************************GET USER*****************************/
	@GetMapping("/getUser/{acc_no}")
	public User getUser( @PathVariable("acc_no") long acc_no) {
		Optional<User> u = userRepo.findById(acc_no);
		User user = u.get();
		return user;
	}
	
	/****************************DEPOSIT*****************************/
	@PostMapping("/deposit/{amount}")
	public boolean deposit(@RequestBody User user, @PathVariable("amount")  float amount) throws UserNotFoundException, AmountInsufficientException{
		try{
			User u = userRepo.findById(user.getAccountNumber()).orElseThrow(() -> new UserNotFoundException("User not found for this id"));
			Bank b = bankRepo.findById(user.getAccountNumber()).orElseThrow(() -> new UserNotFoundException("Bank account not found for this id"));
			float bankBalance = b.getBalance();
			float userBalance = bankBalance + amount;
			b.setBalance(bankBalance-amount);
			u.setBalance(u.getBalance()+amount);
			bankRepo.save(b);
			String statement = "Deposited";
			Date date1 = new Date();
			String date = date1.toString();
			Transaction t = new Transaction(date, user.getAccountNumber(), statement, amount);
			u.addTransaction(t);
			userRepo.save(u);
			return true;
		}
		catch(UserNotFoundException e){
			System.out.println(e.getMessage());
			return false;
		}
		catch (AmountInsufficientException e) {
			return false;
		}
}
	
	/****************************FUND TRANSFER*****************************/
	@PostMapping("/fundtransfer/{amount}/{accountNumber1}")
	public boolean fundTransfer( @RequestBody User user, @PathVariable("amount")  float amount,@PathVariable("accountNumber1") long accountNumber1) throws UserNotFoundException,AmountInsufficientException{
			try{
				System.out.println(user);
				User u = userRepo.findById(user.getAccountNumber()).orElseThrow(() -> new UserNotFoundException("User not found for this id"));
				//Bank b = bankRepo.findById(user.getAccountNumber()).orElseThrow(() -> new UserNotFoundException("Bank account not found for this id"));
				Bank b1 = bankRepo.findById(accountNumber1).orElseThrow(() -> new UserNotFoundException("Bank account not found for this id"));
				Iterable<User> availableUsers1 = userRepo.findAll();
				for(User availableUser1:availableUsers1){
					if(availableUser1.getAccountNumber().equals(accountNumber1)){
						System.out.println("hi");
						u.setBalance(u.getBalance()-amount);
						availableUser1.setBalance(availableUser1.getBalance()+amount);
						String statement = "Transfered to " + accountNumber1;
						Date date1 = new Date();
						String date = date1.toString();
						Transaction t = new Transaction(date, user.getAccountNumber(), statement, amount);
						System.out.println(t);
						u.addTransaction(t);
						userRepo.save(u);
						System.out.println("user saved");
						
						String statement1 = "Credited from account " + user.getAccountNumber();
						Date date2 = new Date();
						String date3 = date2.toString();
						Transaction t1 = new Transaction(date, accountNumber1, statement1, amount);
						availableUser1.addTransaction(t1);
						userRepo.save(availableUser1);
						return true;
					}
				}
				u.setBalance(u.getBalance()-amount);
				b1.setBalance(b1.getBalance()+amount);
				String statement = "Transfered to " + accountNumber1;
				Date date1 = new Date();
				String date = date1.toString();
				Transaction t = new Transaction(date, user.getAccountNumber(), statement, amount);
				System.out.println(t);
				u.addTransaction(t);
				userRepo.save(u);
				System.out.println("user saved");
				return true;
			}
			
			catch(UserNotFoundException e){
				return false;
			}
			catch (AmountInsufficientException e) {
				return false;
			}
		}
		
	/****************************WITHDRAW*****************************/
	@PostMapping("/withdraw/{amount}")
	public boolean withdraw( @RequestBody User user, @PathVariable("amount")  float amount) throws AmountInsufficientException,UserNotFoundException{
		try{
			User u = userRepo.findById(user.getAccountNumber()).orElseThrow(() -> new UserNotFoundException("User not found for this id"));;
			Bank b = bankRepo.findById(user.getAccountNumber()).orElseThrow(() -> new UserNotFoundException("User not found for this id"));;
			
			float bankBalance = b.getBalance();
			float userBalance = u.getBalance();
		
			u.setBalance(userBalance-amount);
			b.setBalance(bankBalance+amount);
			
			bankRepo.save(b);
			String statement = "Withdrawn";
			Date date1 = new Date();
			String date = date1.toString();
			Transaction t = new Transaction(date, user.getAccountNumber(), statement, amount);
			u.addTransaction(t);
			userRepo.save(u);
			return true;
		}
		catch(UserNotFoundException e){
			System.out.println(e.getMessage());
			return false;
		}
		catch (AmountInsufficientException e) {
			return false;
		}
	}
}