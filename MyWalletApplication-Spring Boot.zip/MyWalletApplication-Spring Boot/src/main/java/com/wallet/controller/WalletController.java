package com.wallet.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wallet.exception.AmountInsufficientException;
import com.wallet.exception.UserNotFoundException;
import com.wallet.model.Bank;
import com.wallet.model.Transaction;
import com.wallet.model.User;
import com.wallet.repository.BankRepository;
import com.wallet.repository.TransactionRepository;
import com.wallet.repository.UserRepository;
import com.wallet.service.WalletServiceInterface;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping({"/users"})
public class WalletController {
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private BankRepository bankRepo;
	@Autowired
	private TransactionRepository transactRepo;
	static int i=0;
	@Autowired
	WalletServiceInterface service_interface;
	
	/****************************LOGIN*****************************/
	@PostMapping("/doLogin")
	public User login(@RequestBody User user){
		return service_interface.login(user);
	}
	
	/****************************USER REGISTER*******************************/
	@PostMapping("/create")
	public String create(@RequestBody User user) throws UserNotFoundException, AmountInsufficientException {
		return service_interface.create(user);
}
	
	/****************************GET USER*****************************/
	@GetMapping("/getUser/{acc_no}")
	public User getUser( @PathVariable("acc_no") long acc_no) {
		return service_interface.getUser(acc_no);
	}
	
	/****************************DEPOSIT*****************************/
	@PostMapping("/deposit/{amount}")
	public String deposit(@RequestBody User user, @PathVariable("amount")  float amount) throws UserNotFoundException, AmountInsufficientException{
		return service_interface.deposit(user, amount);
}
	
	/****************************FUND TRANSFER*****************************/
	@PostMapping("/fundtransfer/{amount}/{accountNumber1}")
	public String fundTransfer( @RequestBody User user, @PathVariable("amount")  float amount,@PathVariable("accountNumber1") long receiver_accountNumber) throws UserNotFoundException,AmountInsufficientException{
		return service_interface.fundTransfer(user, amount, receiver_accountNumber);
		}
		
	/****************************WITHDRAW*****************************/
	@PostMapping("/withdraw/{amount}")
	public String withdraw( @RequestBody User user, @PathVariable("amount")  float amount) throws AmountInsufficientException,UserNotFoundException{
		return service_interface.withdraw(user, amount);
	}
}