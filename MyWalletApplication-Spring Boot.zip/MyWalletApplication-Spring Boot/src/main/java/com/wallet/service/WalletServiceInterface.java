package com.wallet.service;

import org.springframework.stereotype.Service;

import com.wallet.exception.AmountInsufficientException;
import com.wallet.exception.UserNotFoundException;
import com.wallet.model.User;

@Service
public interface WalletServiceInterface {
	public User login(User user);
	public String create(User user)throws UserNotFoundException,AmountInsufficientException;
	public User getUser(long acc_no);
	public String deposit(User user, float amount) throws UserNotFoundException, AmountInsufficientException;
	public String fundTransfer(User user, float amount, long receiver_accountNumber) throws UserNotFoundException,AmountInsufficientException;
	public String withdraw(User user, float amount) throws AmountInsufficientException,UserNotFoundException;
}
