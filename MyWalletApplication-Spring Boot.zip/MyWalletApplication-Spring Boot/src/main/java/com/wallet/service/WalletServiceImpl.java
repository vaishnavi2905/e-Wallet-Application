package com.wallet.service;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wallet.exception.AmountInsufficientException;
import com.wallet.exception.UserNotFoundException;
import com.wallet.model.Bank;
import com.wallet.model.Transaction;
import com.wallet.model.User;
import com.wallet.repository.BankRepository;
import com.wallet.repository.TransactionRepository;
import com.wallet.repository.UserRepository;

@Service
public class WalletServiceImpl implements WalletServiceInterface{
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private BankRepository bankRepo;
	@Autowired
	private TransactionRepository transactRepo;
	
	//************************************Login********************************
	@Override
	public User login(User user) {
		int flag=0;
		//find all available users
		Iterable<User> u1 = userRepo.findAll();			
		for(User u:u1){
			//check which user contact and user id matches the input details
			if ((u.getContactNumber().equals(user.getContactNumber())) && (u.getUserID().equals(user.getUserID())))
			{
					flag = 1;
					return u;											//return the user found
			}
		}
		//if non of the user matches then return null
		return null;													
	}
	
	//************************************User Registration********************************
	@Override
	public String create(User user) throws UserNotFoundException,AmountInsufficientException{
		try{
			//Check if the user already exists
			if(userRepo.existsById(user.getAccountNumber()))
				return "User already exists";
			
			//Check if the user has bank account 
			Bank b = bankRepo.findById(user.getAccountNumber()).orElseThrow(() -> new UserNotFoundException("User not found for this id"));
			
			//Check if the details in bank account match the input details
			if(user.getContactNumber().equals(b.getContactNumber()))
			{
				//if details get matched then set necessary details save it in database
				user.setBalance(0);
				user.setName(b.getName());
				userRepo.save(user);					
				return "true";
			}
			return "Enter correct contact number";
		}
		catch(UserNotFoundException e){
			//return appropriate message if user is not found in bank 
			return e.getMessage();
		}
	}
	
	//************************************Get User********************************
	@Override
	public User getUser(long acc_no) {
		//Find the user by using input account number and return user
		Optional<User> u = userRepo.findById(acc_no);
		User user = u.get();
		return user;
	}
	
	//************************************Deposit********************************
	@Override
	public String deposit(User user, float amount) throws UserNotFoundException, AmountInsufficientException {
		try{
			//find the user in user and bank tables
			User u = userRepo.findById(user.getAccountNumber()).orElseThrow(() -> new UserNotFoundException("User not found for this id"));
			Bank b = bankRepo.findById(user.getAccountNumber()).orElseThrow(() -> new UserNotFoundException("Bank account not found for this id"));
			
			//get the bank balance and withdraw money from bank account
			float bankBalance = b.getBalance();
			b.setBalance(bankBalance-amount);

			//deposit bank money into user account i.e user wallet
			u.setBalance(u.getBalance()+amount);
			
			//update the user balance
			bankRepo.save(b);
			
			//store this transaction in user account
			String statement = "Deposited";
			Date date1 = new Date();
			String date = date1.toString();
			Transaction t = new Transaction(date, user.getAccountNumber(), statement, amount);
			u.addTransaction(t);
			userRepo.save(u);
			return "true";
		}
		catch(UserNotFoundException e){
			//return the appropriate message if user not found 
			return e.getMessage();
		}
		catch (AmountInsufficientException e) {
			//return the appropriate message if amount is insufficient
			return e.getMessage();
		}
	}
	
	//************************************Fund Transfer********************************
	@Override
	public String fundTransfer(User user, float amount, long receiver_accountNumber) throws UserNotFoundException, AmountInsufficientException {
		try{
			//check if user has account
			User u = userRepo.findById(user.getAccountNumber()).orElseThrow(() -> new UserNotFoundException("User not found for this id"));
			//check if receiver has bank account
			Bank b = bankRepo.findById(receiver_accountNumber).orElseThrow(() -> new UserNotFoundException("Bank account not found for this id"));
			
			//Check if the receiver user has account i.e having wallet
			Iterable<User> availableUsers1 = userRepo.findAll();
			for(User availableUser1:availableUsers1){
				if(availableUser1.getAccountNumber().equals(receiver_accountNumber)){
					
					//if the user has account then transfer money to the receiver wallet
					u.setBalance(u.getBalance()-amount);
					availableUser1.setBalance(availableUser1.getBalance()+amount);
					
					//store the transaction
					String statement = "Transfered to " + receiver_accountNumber;
					Date date1 = new Date();
					String date = date1.toString();
					Transaction t = new Transaction(date, user.getAccountNumber(), statement, amount);
					System.out.println(t);
					u.addTransaction(t);
					userRepo.save(u);
					
					//store transaction in receiver user's account
					String statement1 = "Credited from account " + user.getAccountNumber();
					Date date2 = new Date();
					String date3 = date2.toString();
					Transaction t1 = new Transaction(date, receiver_accountNumber, statement1, amount);
					availableUser1.addTransaction(t1);
					userRepo.save(availableUser1);
					return "true";
				}
			}
			
			//if receiver has no wallet account the transfer money to bank account
			u.setBalance(u.getBalance()-amount);
			b.setBalance(b.getBalance()+amount);
			
			//store transaction in sender's account
			String statement = "Transfered to " + receiver_accountNumber;
			Date date1 = new Date();
			String date = date1.toString();
			Transaction t = new Transaction(date, user.getAccountNumber(), statement, amount);
			System.out.println(t);
			u.addTransaction(t);
			userRepo.save(u);
			return "true";
		}
		
		catch(UserNotFoundException e){
			//return the appropriate message if user not found 
			return e.getMessage();
		}
		catch (AmountInsufficientException e) {
			//return the appropriate message if amount insufficent
			return e.getMessage();
		}
	}
	
	//************************************Withdraw********************************
	@Override
	public String withdraw(User user, float amount) throws AmountInsufficientException, UserNotFoundException {
		try{
			//check if user has account 
			User u = userRepo.findById(user.getAccountNumber()).orElseThrow(() -> new UserNotFoundException("User not found for this id"));;
			Bank b = bankRepo.findById(user.getAccountNumber()).orElseThrow(() -> new UserNotFoundException("User not found for this id"));;
			
			//withdraw money from wallet and deposit back to bank account
			float bankBalance = b.getBalance();
			float userBalance = u.getBalance();
			u.setBalance(userBalance-amount);
			b.setBalance(bankBalance+amount);
			//update the user to set balance
			bankRepo.save(b);
			//store the transaction
			String statement = "Withdrawn";
			Date date1 = new Date();
			String date = date1.toString();
			Transaction t = new Transaction(date, user.getAccountNumber(), statement, amount);
			u.addTransaction(t);
			userRepo.save(u);
			return "true";
		}
		catch(UserNotFoundException e){
			//return the appropriate message if user not found
			return e.getMessage();
		}
		catch (AmountInsufficientException e) {
			//return the appropriate message if amount insufficent
			return e.getMessage();
		}
	}

}
