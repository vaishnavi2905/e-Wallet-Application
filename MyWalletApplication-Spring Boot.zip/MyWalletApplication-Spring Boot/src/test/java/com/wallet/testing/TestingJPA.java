package com.wallet.testing;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.wallet.controller.WalletController;
import com.wallet.exception.AmountInsufficientException;
import com.wallet.model.User;
import com.wallet.repository.UserRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
public class TestingJPA {
	private static Logger logger=LogManager.getRootLogger();
	@Autowired
	private UserRepository userRepo;
	
	@BeforeAll
	static void setUpBeforeClass() {
		logger = LogManager.getRootLogger();
		System.out.println("Fetching resources for testing ...");
	}
	
	//**********************JPA save************************
	@Test
    public void create() throws AmountInsufficientException{
		logger.info("Test case - Check JPA save() method");
		User u = new User();
		u.setAccountNumber((long) 160210);
		u.setName("Vaishnavi");
		u.setContactNumber(new BigInteger("8275811329"));
		u.setUserID("2905");
		u.setBalance(0);
		userRepo.save(u);
		Optional<User> u1=userRepo.findById((long) 160210);
		User user = u1.get();
		assertEquals(u.getName(), user.getName());
		assertEquals(u.getContactNumber(), user.getContactNumber());
	}
	
	//**********************JPA save for update************************
	@Test
	public void update() throws AmountInsufficientException{
		logger.info("Test case - Check JPA save() method for update");
		User u = new User();
		u.setAccountNumber((long) 160210);
		u.setName("Vaishnavi");
		u.setContactNumber(new BigInteger("8275811329"));
		u.setUserID("2905");
		u.setBalance(0);
		userRepo.save(u);
		Optional<User> u1=userRepo.findById((long) 160210);
		User user = u1.get();
		user.setBalance(100);
		user.setName("ABC");
		userRepo.save(user);
		assertNotEquals(u.getBalance(),user.getBalance());
		assertNotEquals(u.getName(), user.getName());
	}
	
	//**********************JPA findAll************************
	@Test
	public void getAll() throws AmountInsufficientException {
		logger.info("Test case - Check JPA findAll() method");
		User u1 = new User();
		u1.setAccountNumber((long) 160219);
		u1.setName("DEF");
		u1.setContactNumber(new BigInteger("8275811329"));
		u1.setUserID("2935");
		u1.setBalance(10);
		userRepo.save(u1);
		assertNotNull(userRepo.findAll());
	}
}
