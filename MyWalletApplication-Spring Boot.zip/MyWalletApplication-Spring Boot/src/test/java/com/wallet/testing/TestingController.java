package com.wallet.testing;

import static org.junit.Assert.*;

import java.math.BigInteger;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;

import com.wallet.controller.WalletController;
import com.wallet.exception.AmountInsufficientException;
import com.wallet.exception.UserNotFoundException;
import com.wallet.model.User;
import com.wallet.repository.UserRepository;

@RunWith(SpringRunner.class)
@ExtendWith(SpringExtension.class)
@SpringBootTest
public class TestingController {
	@Autowired
	private WalletController controller;
	@Autowired
	private UserRepository userRepo;
	@Test
	public void checkCreate() throws UserNotFoundException, AmountInsufficientException{
		User user=new User((long) 160217,"Sujal",new BigInteger("9423211917"),0,"0304");
		boolean status = controller.create(user);
		assertEquals(true, status);
	}
	
	@Test
	public void checkLogin(){
		User user=new User((long) 160217,"Sujal",new BigInteger("9423211917"),0,"0304");
		User u = controller.login(user);
		assertEquals(user.getName(), u.getName());
	}
	
	@Test
	public void checkDeposit() throws UserNotFoundException, AmountInsufficientException{
		User user=new User((long) 160217,"Sujal",new BigInteger("9423211917"),0,"0304");
		float amount = 500;
		boolean status = controller.deposit(user, amount);
		assertEquals(true, status);
	}
	
	@Test
	public void checkFundTransfer() throws UserNotFoundException, AmountInsufficientException{
		User user=new User((long) 160217,new BigInteger("9423211917"),"0304");
		float amount = 100;
		long accountNumber1=160210;
		boolean status = controller.fundTransfer(user, amount, accountNumber1);
		assertEquals(true, status);
	}
	@Test 
	public void checkGetUser(){
		User u = controller.getUser((long)160217);
		assertNotNull(u);
	}
}
