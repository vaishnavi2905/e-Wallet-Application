package com.wallet.testing;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MyWalletApplicationTest {
	 @Test
	 void contextLoads(){
		 
	 }
}
