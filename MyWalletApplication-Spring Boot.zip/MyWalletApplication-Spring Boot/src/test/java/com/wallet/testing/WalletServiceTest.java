package com.wallet.testing;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigInteger;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.wallet.exception.AmountInsufficientException;
import com.wallet.exception.UserNotFoundException;
import com.wallet.model.User;
import com.wallet.service.WalletServiceInterface;

@RunWith(SpringRunner.class)
@ExtendWith(SpringExtension.class)
@Transactional
@SpringBootTest
public class WalletServiceTest {
	
	private static Logger logger=LogManager.getRootLogger();
	
	@Autowired
	private WalletServiceInterface service_interface;
	
	@BeforeAll
	static void setUpBeforeClass() {
		logger = LogManager.getRootLogger();
		System.out.println("Fetching resources for testing ...");
	}
	
	//***************************User registration*************************
	@Test
	@Rollback(false)
	public void testA() throws UserNotFoundException, AmountInsufficientException{
		logger.info("Test case - User registration successful");
		User user=new User((long) 160217,"Sujal",new BigInteger("9423211917"),0,"0304");
		String message = service_interface.create(user);
		assertEquals("true", message);
	}
	@Test
	public void testB() throws UserNotFoundException, AmountInsufficientException{
		logger.info("Test case - User registration failure (User already exists)");
		User user=new User((long) 160217,"Sujal",new BigInteger("9423211917"),0,"0304");
		String message = service_interface.create(user);
		assertEquals("User already exists", message);
	}
	@Test
	public void testC() throws UserNotFoundException, AmountInsufficientException{
		logger.info("Test case - User registration failure (Incorrect Contact number)");
		User user=new User((long) 160221,"Sita",new BigInteger("942321191"),0,"0304");
		String message = service_interface.create(user);
		assertEquals("Enter correct contact number", message);
	}
	@Test
	public void testD() throws UserNotFoundException, AmountInsufficientException{
		logger.info("Test case - User registration failure (User not found)");
		User user=new User((long) 160219,"Sujal",new BigInteger("9423211917"),0,"0304");
		String message = service_interface.create(user);
		assertEquals("User not found for this id", message);
	}
	
	//***************************User login********************************
	@Test
	public void testE(){
		logger.info("Test case - User login successful");
		User user=new User((long) 160217,"Sujal",new BigInteger("9423211917"),0,"0304");
		User u = service_interface.login(user);
		assertEquals(user.getName(), u.getName());
	}
	@Test
	public void testF(){
		logger.info("Test case - User login failure");
		User user=new User((long) 160217,"Sujal",new BigInteger("9423211919"),0,"0300");
		User u = service_interface.login(user);
		assertEquals(null, u);
	}
	
	//***************************Get User Details*************************
	@Test 
	public void testG(){
		logger.info("Test case - Get User details");
		User u = service_interface.getUser((long)160217);
		assertNotNull(u);
	}
	
	//***************************Deposit money*************************
	@Test
	public void testH() throws UserNotFoundException, AmountInsufficientException{
		logger.info("Test case - Deposit money successfully");
		User user=new User((long) 160217,"Sujal",new BigInteger("9423211917"),0,"0304");
		float amount = 1000;
		String status = service_interface.deposit(user, amount);
		assertEquals("true", status);
	}
	@Test
	public void testI() throws UserNotFoundException, AmountInsufficientException{
		logger.info("Test case - Deposit money failure(User not found)");
		User user=new User((long) 160219,"Sujal",new BigInteger("9423211917"),0,"0304");
		float amount = 500;
		String status = service_interface.deposit(user, amount);
		assertEquals("User not found for this id", status);
	}
	@Test
	public void testJ() throws UserNotFoundException, AmountInsufficientException{
		logger.info("Test case - Deposit money failure(Insufficient amount in bank)");
		User user=new User((long) 160217,"Sujal",new BigInteger("9423211917"),0,"0304");
		float amount = 50000;
		String status = service_interface.deposit(user, amount);
		assertEquals("Amount insufficient", status);
	}
	
	//***************************Withdraw money*************************
	@Test
	public void testK() throws UserNotFoundException, AmountInsufficientException{
		logger.info("Test case - Withdraw money successfully");
		User user=new User((long) 160210,"Vaishnavi",new BigInteger("8275811329"),0,"2905");
		float amount = 10;
		String status = service_interface.withdraw(user, amount);
		assertEquals("true", status);
	}
	@Test
	public void testL() throws UserNotFoundException, AmountInsufficientException{
		logger.info("Test case - Withdraw money failure(User not found)");
		User user=new User((long) 160219,"Sujal",new BigInteger("9423211917"),0,"0304");
		float amount = 100;
		String status = service_interface.withdraw(user, amount);
		assertEquals("User not found for this id", status);
	}
	@Test
	public void testM() throws UserNotFoundException, AmountInsufficientException{
		logger.info("Test case - Withdraw money failure (Insufficient amount in bank)");
		User user=new User((long) 160217,"Sujal",new BigInteger("9423211917"),0,"0304");
		float amount = 10000;
		String status = service_interface.withdraw(user, amount);
		assertEquals("Amount insufficient", status);
	}
	
	//***************************Fund Transfer*************************
	@Test
	public void testN() throws UserNotFoundException, AmountInsufficientException{
		logger.info("Test case - Fund Transfer successful");
		User user=new User((long) 160212,"Vaijnath",new BigInteger("7350008785"),0,"2315");
		float amount = 50;
		long receiver_accountNumber=160213;
		String status = service_interface.fundTransfer(user, amount, receiver_accountNumber);
		assertEquals("true", status);
	}
	@Test
	public void testO() throws UserNotFoundException, AmountInsufficientException{
		logger.info("Test case - Fund Transfer failure(User not found)");
		User user=new User((long) 160219,"Sujal",new BigInteger("9423211917"),0,"0304");
		float amount = 100;
		long receiver_accountNumber=160210;
		String status = service_interface.fundTransfer(user, amount, receiver_accountNumber);
		assertEquals("User not found for this id", status);
	}
	@Test
	public void testP() throws UserNotFoundException, AmountInsufficientException{
		logger.info("Test case - Fund Transfer failure(Insufficient amount)");
		User user=new User((long) 160217,"Sujal",new BigInteger("9423211917"),0,"0304");
		float amount = 10000;
		long receiver_accountNumber=160210;
		String status = service_interface.fundTransfer(user, amount, receiver_accountNumber);
		assertEquals("Amount insufficient", status);
	}
	@Test
	public void testQ() throws UserNotFoundException, AmountInsufficientException{
		logger.info("Test case - Fund Transfer failure(Receiver user not found)");
		User user=new User((long) 160217,"Sujal",new BigInteger("9423211917"),0,"0304");
		float amount = 100;
		long receiver_accountNumber=160219;
		String status = service_interface.fundTransfer(user, amount, receiver_accountNumber);
		assertEquals("Bank account not found for this id", status);
	}
}
