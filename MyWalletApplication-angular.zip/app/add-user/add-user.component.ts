import { Component, OnInit } from '@angular/core';
import { HttpClientService, User } from '../Service/http-client.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  user: User = new User("","","","","",null);
  
  constructor(
    private httpClientService: HttpClientService,
    private router : Router
  ) { }

  ngOnInit() {
  }
  createUser(): void {
    console.log(this.user);
    this.httpClientService.createUser(this.user)
      .subscribe( data => {
        console.log(data);
        if(data){
          alert("User registered successfully.");
          this.router.navigate(['login']);
        }
        else{
          alert("Account Number not available in bank. Please enter correct account details");
          this.router.navigate(['adduser']);
        }
      }
    );
  };
}
