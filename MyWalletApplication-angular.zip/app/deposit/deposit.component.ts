import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { HttpClientService, User } from '../Service/http-client.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  user: User = new User("","","","","",null);
  amount;
  currentUser = sessionStorage.getItem('username');
  userData=new User("","","","","",null);
  constructor(
    private router: Router,
    private loginservice: AuthenticationService,
    private httpClientService: HttpClientService,
  ) { }

  ngOnInit() {
    this.httpClientService.getUser(this.currentUser).subscribe(data => this.userData = data);
  }
  deposit(){
    if(this.user.accountNumber==this.currentUser){
      if(this.user.userID==this.userData.userID){
        this.httpClientService.deposit(this.user,this.amount).subscribe(
        x=>{
          if(x)
          {
            alert("Amount deposited successfully");
            this.router.navigate(['home']);
          }
          else{
            alert("Amount not available in bank");
            this.router.navigate(['deposit']);
          }
        });
      }
      else{
            alert("Invalid user ID");
            this.router.navigate(['deposit']);
      }
    }
    else{
      alert("Please enter correct account number");
    }
  }
}
