import { Component, OnInit } from '@angular/core';
import { User, HttpClientService } from '../Service/http-client.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {
  user: User = new User("","","","","",null);
  amount;
  accountNumber1;
  currentUser;
  constructor(
    private router: Router,
    private loginservice: AuthenticationService,
    private httpClientService: HttpClientService,
  ) { }

  ngOnInit() {
  }
  fundTransfer(){
    this.currentUser = sessionStorage.getItem('username');
    if(this.user.accountNumber===this.currentUser){
      this.httpClientService.fundTransfer(this.user,this.amount,this.accountNumber1).subscribe(
      x=>{
        if(x)
        {
          console.log(x);
          alert("Amount transfered successfully");
          this.router.navigate(['home']);
        }
        else{
          alert("Receiver bank account does not exist");
          this.router.navigate(['fundtransfer']);
        }
      });
    }
    else{
      alert("Please enter correct account number");
    }
  }
}
