import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { HttpClientService, User } from '../Service/http-client.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  user: User = new User("","","","","",null);
  amount;
  currentUser;
  constructor(
    private router: Router,
    private loginservice: AuthenticationService,
    private httpClientService: HttpClientService,
  ) { }

  ngOnInit() {
  }
  deposit(){
    this.currentUser = sessionStorage.getItem('username');
    if(this.user.accountNumber===this.currentUser){
      this.httpClientService.deposit(this.user,this.amount).subscribe(
      x=>{
        if(x)
        {
          alert("Amount deposited successfully");
          this.router.navigate(['home']);
        }
        else{
          alert("Amount not available in bank");
          this.router.navigate(['deposit']);
        }
      });
    }
    else{
      alert("Please enter correct account number");
    }
  }
}
