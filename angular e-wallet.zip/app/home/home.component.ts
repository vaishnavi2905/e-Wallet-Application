import { Component, OnInit } from '@angular/core';
import { HttpClientService, User } from '../Service/http-client.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  user = sessionStorage.getItem('username')
  userData=new User("","","","","",null);
  transactions;
  constructor(
    private router: Router,
    private loginservice: AuthenticationService,
    private httpClientService: HttpClientService,
    
  ) { }
  ngOnInit() {
    this.httpClientService.getUser(this.user).subscribe(data => this.userData = data);
  }
  
}
