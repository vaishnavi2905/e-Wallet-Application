import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RequestOptions } from '@angular/http';


  export class User{
    constructor(
      public accountNumber:string,
      public name:string,
      public contactNumber:string,
      public balance:string,
      public userID:string,
      public transaction:Transaction
    ) {}
}
export class Transaction{
  constructor(
    public accountNumber:string,
    public statement:string,
    public time:string,
    public amount:string,
  ) {}
}
@Injectable({
  providedIn: 'root'
})
export class HttpClientService {

  constructor(
    private httpClient:HttpClient
  ) { 
     }

  public createUser(user):Observable<any>{
    return this.httpClient.post<any>("http://localhost:8080/users"+"/create", user);
  }
  getUser(acc_no):Observable<User>{
    return this.httpClient.get<User>(`http://localhost:8080/users/getUser/${acc_no}`);
}

  deposit(user,amount):Observable<any>{
    const baseURL='http://localhost:8080/users';
    console.log(user);
    console.log(amount);
    return this.httpClient.post<any>(`${baseURL}/deposit/${amount}`, user);
  }
  withdraw(user,amount):Observable<any>{
    console.log(user);
    console.log(amount);
    return this.httpClient.post<any>(`http://localhost:8080/users/withdraw/${amount}`, user);
  }
  fundTransfer(user,amount,accountNumber1):Observable<any>{
    console.log(user);
    console.log(amount);
    console.log(accountNumber1);
    return this.httpClient.post<any>(`http://localhost:8080/users/fundtransfer/${amount}/${accountNumber1}`, user);
  }
}